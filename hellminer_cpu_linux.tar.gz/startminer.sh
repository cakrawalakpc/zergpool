./hellminer -c stratum+ssl://verushash.asia.mine.zergpool.com:3300 -u ADDRESS.WORKER -p x --cpu 1
